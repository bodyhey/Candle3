
This is a copy of a previous version of share/qtcreator/debugger/*.py
which supported Python 2 and Python 3 based debugger backends (gdb,
lldb) at the same time.

The code there is now Python-3-only. This copy here is not meant to be
used in general but could perhaps be used to replace the main code
in situations that cannot use Python 3 yet.
